iterazioni_da_avviare = 1

# caratterizzazione produzione (potenza impianto ==> energia)
ore_al_giorno=4
re_scale_pvpower = ore_al_giorno / 24 #* 15
# produzione e distribuzione idrogeno
tons_per_MW = 33
tons_per_kW = 0.033
Routing_to_LoS =1.5

# opzioni solver 
ordine_costo = 1
mipgap =0.05

minori_di_selezionati=True #ci possono essere meno P2G selezionati rispetto al totale dei punti in lista?
import os
import csv
import pandas as pd   
import numpy as np    
import geopandas as gpd
from datetime import datetime
import time
from string import *
import random

import pyomo.environ as pyo

dizionario={}

cartella_base = './'
cartella_accantonati=cartella_base+"dati_accantonati/"
file_condizioni_simulate= 'condizioni_simulazioni.txt'
with open(cartella_accantonati+file_condizioni_simulate, mode ='r') as file:
    csvFile = csv.reader(file, delimiter = '\t')
    conta=1
    for row in csvFile:
        dizionario_riga = {'fuel_fraction': float(row[0])/100,'scenario':row[1],
                           'anno':row[2], 'taglie':[int(x) for x in row[3].strip('][').split(', ')],
                           'truck_km':float(row[4])}
        dizionario[conta] = dizionario_riga
        conta+=1

'''costo_p2g = p1 * cap + p0'''
p1_lin = 2985; p0_lin = 4.53E6 #€/kw  ed €

def init_precalc(modello, precalc_i, precalc_j):
    return precalcolati[precalc_i-1][precalc_j-1]

def demand_(model_d, j_d): # All of the demand for customer j must be satisfied
    return sum(model_d.xd[i_d,j_d] for i_d in model_d.M) == 1
def demand_cap_(model_cap, i_dcap): # In uscita flussi verso gli utenti sono inferiori alla producibilità
    # forse tons_per_kW
    return tons_per_kW * model_cap.cap[i_dcap] - sum(model_cap.xd[i_dcap,j_dcap]*model_cap.d[j_dcap] for j_dcap in model_cap.N) >= 0


def offer_fissata_(model_o, i_o): # All of the offers from plant j must be exported >= --> surplus in eccesso
    return sum(model_o.xo[i_o,k_o] for k_o in model_o.L) == 1.0
def offer_max_(model_o, i_o): # All of the offers from plant j must be exported >= --> surplus in eccesso
    return sum(model_o.xo[i_o,k_o] for k_o in model_o.L) <= 1.01
def offer_min_(model_o, i_o): # All of the offers from plant j must be exported >= --> surplus in eccesso
    return sum(model_o.xo[i_o,k_o] for k_o in model_o.L) >= 0.95

def truck_distance_(model_dist): #la somma deipercorsi troppo lunghi * frazione di flusso deve essere nulla
    return sum(sum(model_dist.xd[i_dist,j_dist] * precalcolati[i_dist-1 ,j_dist-1] for i_dist in model_dist.M) for j_dist in model_dist.N) == 0

def truck_distance_2D_(model_dist, i_dist, j_dist): 
        if precalcolati[i_dist-1 ,j_dist-1] == 0:
            return pyo.Constraint.Feasible
        return model_dist.xd[i_dist,j_dist] == 0

def open_facilities_(model_openfac): ### selezionando all'inizio...
    if minori_di_selezionati == False:
        return sum(model_openfac.y[i_openfac] for i_openfac in model_openfac.M) == model_openfac.p
    else:
        return sum(model_openfac.y[i_openfac] for i_openfac in model_openfac.M) <= model_openfac.p

def d_openfac_(model_dof, i_dof, j_dof): # Demand nodes can only be assigned to open facilities
    return model_dof.xd[i_dof,j_dof] <= model_dof.y[i_dof]

def o_openfac_(model_oof, i_oof, k_oof):
    return model_oof.xo[i_oof,k_oof] <= model_oof.y[i_oof]

def somma_d_openfac_(model_sdof, i_sdof): # Demand nodes can only be assigned to open facilities
    return sum(model_sdof.xd[i_sdof,j_sdof] for j_sdof in model_sdof.N) <= model_sdof.y[i_sdof]

def somma_o_openfac_(model_soof, i_soof):
    return sum(model_soof.xo[i_soof,k_soof] for k_soof in model_soof.L) <= model_soof.y[i_soof]

def capex_opex_gomma(domanda, distanza_truck):
    return 10.9 * distanza_truck * domanda * 20
#     €   €/km/ton/y     km       ton

def init_cd(modello, init_cd_i, init_cd_j):
    return cd_dist_mtrx[init_cd_i-1][init_cd_j-1]

def init_distanzadarete(modello, dist_i): # co[i,k] - unit cost of offering plant k to facility i
    return np.round(vettore_distanze_rete_P2G[dist_i-1],1)

def coord_convert(x):
    return round(dms2dec(x), 5)

def costo_elettrico(potenza, distanza):
    return 6000 + (4 + 7.5 * distanza ) * potenza #potenza in kW, distanza in km

def capex_elettrolizzatore(capacita):
    costo = p0_lin + capacita * p1_lin
    return costo

def cost_(model_cost): ## FUNZIONEOBIETTIVO ##    
    CAPEX_p2g=sum(capex_elettrolizzatore(model_cost.cap[i]) for i in model_cost.M)
    OPEX_elettrico_20 = 61.9  *  50  * domanda_complessiva * 20
    costo_sinistro_nuovo = sum(costo_elettrico(model_cost.y[i] *model_cost.cap[i], model_cost.distanzadarete[i]) for i in model_cost.M)
    costo_destro = sum(sum(capex_opex_gomma(model_cost.d[j]*model_cost.xd[i,j], model_cost.cd[i,j]) for i in model_cost.M) for j in model_cost.N)
    da_sottrarre=p0_lin * (magazzini - np.count_nonzero(list(model.cap.extract_values().values())))
    obiettivo = CAPEX_p2g + OPEX_elettrico_20 + costo_destro + costo_sinistro_nuovo - da_sottrarre
    return obiettivo/1E6


soglia_capacita_minima_convertitore=0

cartella=cartella_base+"RISULTATI/"
nome_file_base = "anagrafe_distributori"
anagrafe_distributori_autostrade=pd.read_excel(cartella_accantonati + nome_file_base +".xlsx")

adesso=datetime.now()
prefisso_iniziale=f'{adesso.year}{adesso.month:02d}{adesso.day:02d}_{adesso.hour:02d}{adesso.minute:02d}{adesso.second:02d}_'

rete_globale = gpd.read_file(cartella_accantonati+"rete_sinistra.shp")
aux_centroidi_mesh_interni = gpd.read_file(cartella_accantonati+"centroidi_interni.shp")
magazzini_list = np.load(cartella_accantonati+"magazzini_list.npy")    
locations_list = np.load(cartella_accantonati+"locations_list.npy")    
destinations_list = np.load(cartella_accantonati+"destinations_list.npy")    
co_dist_mtrx = np.load(cartella_accantonati+"co_dist_mtrx.npy")
cd_dist_mtrx = np.load(cartella_accantonati+"cd_dist_mtrx.npy")    
vettore_distanze_rete_P2G = np.load(cartella_accantonati+"vettore_distanze_rete_P2G.npy")    
CLU_potenze =  np.load(cartella_accantonati+"potenze_generazione.npy")
condizioni_ultima_prova = np.load(cartella_accantonati+"condizioni.npy")
passofine = condizioni_ultima_prova[0]
dezoom = condizioni_ultima_prova[1]
n_quadratoni = condizioni_ultima_prova[2]
n_quadratini = condizioni_ultima_prova[3]
prefisso_territorio = condizioni_ultima_prova[4]


magazzini=len(magazzini_list)
utenti=len(destinations_list)
fonti=len(locations_list)
selezionati=magazzini
random.seed(1000)


''' ciclo principale '''
for iterazioni_sim, dv in dizionario.items():
    
    CARTELLA_SALVATAGGI = 'SIM'+prefisso_iniziale + str(iterazioni_sim).zfill(3)
    path = os.path.join(cartella, CARTELLA_SALVATAGGI)
    os.mkdir(path)#, 0o666)
    prefisso=CARTELLA_SALVATAGGI+"/"
    frazione_sostituita = dv['fuel_fraction']; opzione_consumi = dv['scenario']; taglie_possibili = dv['taglie']
    anno_di_riferimento = dv['anno']; truck_autonomy = dv['truck_km']
    
    colonna_consumi = 'H2_t_y_'+anno_di_riferimento+'_'+opzione_consumi    
    domande_casuali = np.round(frazione_sostituita * np.array(anagrafe_distributori_autostrade[colonna_consumi]),3)
    domanda_complessiva = sum(domande_casuali)
                
    quante_taglie=len(taglie_possibili); soglia_sensibilita=0.05 #frazione del flusso minimo (bidirezionale)
    
    ############### le variabili del modello sono dizionari ####################
    chiavi_xd0 = [(k+1) for k in range(utenti)]  #indici per richieste_random_iniziali
    domande_casuali_dict=dict(zip(chiavi_xd0, domande_casuali)) # d[j] - demand of customer j
    domanda_minima=min(domande_casuali)    
    domanda_aggregata=domande_casuali
    chiavi_xo0 = [(l+1) for l in range(fonti)]  #indici per richieste_random_iniziali
    ''' ri-scalato con le ore-giorno per il PV'''
    offerte_casuali=np.array(CLU_potenze) * re_scale_pvpower
    offerte_casuali_dict=dict(zip(chiavi_xo0, offerte_casuali)) # o[k] - offer of plant k
    offerta_minima=min(offerte_casuali)    
    flusso_minimo=min(domanda_minima, offerta_minima)
    
    # y[i] - a binary value that is 1 is a facility is located at location i
    chiavi_y0 = [(i+1) for i in range(magazzini)]
    aperture_casuali=[random.randint(0, 1) for _ in range(magazzini)] ##### for m in range(magazzini) ] #richieste
    aperture_casuali_dict=dict(zip(chiavi_y0, aperture_casuali))
    chiavi_cap0 = [(i+1) for i in range(magazzini)]
    indici_casuali=[random.randint(1,quante_taglie)-1 for _ in range(magazzini)]
    cap_casuali=list(map(lambda i : taglie_possibili[i], indici_casuali))
    cap_casuali_dict=dict(zip(chiavi_cap0, cap_casuali))
    chiavi_taglie = [(i+1) for i in range(quante_taglie)]    
    select_dict=dict(zip(chiavi_taglie, taglie_possibili))
    precalcolati = np.zeros(shape=(magazzini,utenti), dtype=int)
    for i in range(magazzini):
        for j in range(utenti):
            precalcolati[i,j] = cd_dist_mtrx[i,j] > truck_autonomy and 1 or 0
    
    ''' dichiaro il lmodello''' 
    model = pyo.ConcreteModel()   
    
    ''' i dati conosciuti del modello: parametri e domini dei parametri '''    
    model.ammissibili=pyo.Set(initialize=taglie_possibili)
    model.m = pyo.Param(within=pyo.PositiveIntegers, default=magazzini) # Number of candidate locations
    model.n = pyo.Param(within=pyo.PositiveIntegers, default=utenti) # Number of customers
    model.l = pyo.Param(within=pyo.PositiveIntegers, default=fonti) # Number of plants
    model.M = pyo.RangeSet(1,model.m) # Set of candidate locations
    model.N = pyo.RangeSet(1,model.n) # Set of customer nodes
    model.L = pyo.RangeSet(1,model.l) # Set 0.0 t/y of generation nodes
    model.p = pyo.Param(within=pyo.RangeSet(1,model.m), default=selezionati) # Number of facilities
    model.precalcolati = pyo.Param(model.M, model.N, initialize=init_precalc, within=pyo.Binary)    
    model.d = pyo.Param(model.N, initialize=domande_casuali_dict, within=pyo.NonNegativeReals)
    model.o = pyo.Param(model.L, initialize=offerte_casuali_dict, within=pyo.NonNegativeReals)    
    model.cd = pyo.Param(model.M, model.N, initialize=init_cd, within=pyo.NonNegativeReals)
    model.distanzadarete = pyo.Param(model.M, initialize=init_distanzadarete, within=pyo.NonNegativeReals)

    frazione_iniziale_xo = 1 / fonti
    frazione_iniziale_xd = 30 / magazzini
    model.xd = pyo.Var(model.M, model.N, bounds=(0.0, 1.0), domain=pyo.NonNegativeReals, initialize=frazione_iniziale_xd)
    for i in range(magazzini):
        for j in range(utenti):
            if precalcolati[i,j]!=0:
                model.xd[i+1, j+1].set_value(0, skip_validation=False) # = pyo.Var(bounds=(0.0 1.0), initialize=frazione_iniziale_xd)

    model.xo = pyo.Var(model.M, model.L, bounds=(0.0, 1.0), initialize=frazione_iniziale_xo) 
    for i in range(magazzini):
        for k in range(fonti):
            model.xo[i+1, k+1].set_value(float(i==k), skip_validation=False)
    
    model.y = pyo.Var(model.M, domain=pyo.Binary, initialize= aperture_casuali_dict)    
    model.cap = pyo.Var(model.M, initialize=cap_casuali_dict, bounds=(0, 10000), domain=pyo.NonNegativeReals)    
    
    ''' VINCOLI DEL PROBLEMA '''
    model.truck_distance_2D = pyo.Constraint(model.M, model.N, rule=truck_distance_2D_)
    model.demand = pyo.Constraint(model.N, rule=demand_)
    model.offer_fissata = pyo.Constraint(model.M, rule=offer_fissata_)    
    model.demand_cap = pyo.Constraint(model.M, rule=demand_cap_)
    
    ''' vincoli sulle aperture, y '''
    model.open_facilities_ = pyo.Constraint(rule=open_facilities_)
    model.d_openfac = pyo.Constraint(model.M, model.N, rule=d_openfac_)
    model.o_openfac = pyo.Constraint(model.M, model.L, rule=o_openfac_)
    
    model.cost = pyo.Objective(rule=cost_, sense=pyo.minimize)
    ########################################################################
    
    opt = pyo.SolverFactory('gurobi', solve_io="python")
    opt.options['MIPGap'] = mipgap
    
    opt.options['NonConvex'] = 2
    opt.options['Presolve']=-1 # -1: Automatico, 0: Spento, 1: Presente, 2: Aggressivo

    t0 = time.time()
    results  =opt.solve(model, tee=False)    
    t_batch = round(time.time() - t0, 2); print(f'tempo di ricerca ottimo= {t_batch} s')

    matrice_xd=np.zeros(shape=(magazzini,utenti), dtype=float)
    matrice_xo=np.zeros(shape=(magazzini,fonti), dtype=float)
    soglia_flusso_significativo=flusso_minimo*soglia_sensibilita

    instance = model
    prelievi = instance.xo.get_values().items()
    consegne = instance.xd.get_values().items()

    print("")
    print(f'costo totale = {round(instance.cost())}')
    print("")

    lista_punti_neri=[]
    
    lista_entrate_punti_neri=[]
    lista_uscite_punti_neri=[]
    installazioni_vere = 0
    for i in range(magazzini):
        if instance.cap[i+1]() > 0:            
            installazioni_vere += 1
            entrata=0
            for k in range(fonti):
                entrata += instance.xo[i+1,k+1]() * instance.cap[i+1]()
            lista_entrate_punti_neri.append(entrata) #converto in kW per coerenza con le capacità
            uscita=0
            for j in range(utenti):
                uscita += instance.xd[i+1,j+1]() * instance.d[j+1]
            lista_uscite_punti_neri.append(uscita)
            lista_punti_neri.append(i)

    
    lista_xo_ridotta=[]
    for sottostazione in range(magazzini): #corrispondenza 1 a 1 con le stazioni della rete
        if instance.cap[sottostazione+1]() > 0:
            lista_xo_ridotta.append([sottostazione, sottostazione, 1.0])            
        
    lista_xd_ridotta=[]
    for i in range(magazzini):
        if instance.cap[i+1]()>0:
            for j in range(utenti):                
                BBB = round(instance.xd[i+1,j+1](),3)
                matrice_xd[i][j]=BBB
                if BBB>0:
                    lista_xd_ridotta.append([i,j,BBB])

    for k in range(fonti):
        generazione=0
        for i in range(magazzini):         
            generazione += instance.xo[i+1,k+1]() * instance.cap[i+1]()


    for j in range(utenti):
        consumo=0
        for i in range(magazzini):
            consumo += instance.xd[i+1,j+1]() * instance.d[j+1]    

    # field names
    filename = "condizioni.txt"
    with open(cartella+prefisso+filename, "wt")  as text_file:
        text_file.write(f'fuel_pct\t{frazione_sostituita}\nscenario\t{opzione_consumi}\nanno\t{anno_di_riferimento}\n')
        text_file.write(f'taglie\t{taglie_possibili}\ntruck_km\t{truck_autonomy}\nmesh\t{passofine}\n')
        text_file.write(f'dezoom\t{dezoom}\nQuadratoni\t{n_quadratoni}\nQuadratini\t{n_quadratini}\n')
        text_file.write(f'costo\t{instance.cost()}\nmpigap\t{mipgap}\n')
    
    filename = "sottostazioni.csv"
    nomi_colonne = ['id_sottostazione', 'longitudine', 'latitudine']   
    righe_da_scrivere=[]    
    for punto in lista_punti_neri:
        if instance.cap[punto+1]() > 0:
            righe_da_scrivere.append([punto, round(locations_list[punto][0],6), round(locations_list[punto][1],6)])
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)         
        csvwriter.writerow(nomi_colonne)         
        csvwriter.writerows(righe_da_scrivere)
    
    filename = "convertitori.csv"
    nomi_colonne = ['id_convertitore', 'capacita', 'longitudine', 'latitudine', 'CAPEX', 'costo_sx', 'capex_opex_gomma', 'input_power_kW', 'output_H2_tons', 'used%']
    righe_da_scrivere=[]    
    riassunto_CAPEX=0
    riassunto_SX=0
    riassunto_DX=0
    abbreviazione_colonne=['id_P2G', 'cap_kW', 'long.', 'lat.', 'k€CAPEX', 'k€_SX', 'k€_DX', 'kW_in', 'H2_ton', 'used%']
    print('\t\t'.join(abbreviazione_colonne))
    lista_capacita_finale=list(instance.cap.extract_values().values())
    contafasulli=len(lista_capacita_finale)-np.count_nonzero(lista_capacita_finale)
    for i, punto in enumerate(lista_punti_neri):
        temp_c = lista_capacita_finale[punto]
        if temp_c > soglia_capacita_minima_convertitore:                        
            lista_singoli_flussi_dx = [capex_opex_gomma(instance.d[j+1]*instance.xd[punto+1,j+1].value, instance.cd[punto+1,j+1]) for j in range(utenti)]
            singolo_costo_dx = sum(lista_singoli_flussi_dx)            
            singolo_costo_sx = costo_elettrico(instance.cap[punto+1].value,instance.distanzadarete[punto+1])            
            riassunto_SX += singolo_costo_sx
            riassunto_DX += singolo_costo_dx            
            capex_singolo = round(capex_elettrolizzatore(temp_c), 1)            
            riassunto_CAPEX += capex_singolo            
            quanto_entra = round(lista_entrate_punti_neri[i])
            quanto_esce = round(lista_uscite_punti_neri[i],2)
            percentuale_uso = round(quanto_esce / quanto_entra / tons_per_kW * 100, 1)
            da_scrivere=[lista_punti_neri[i], round(temp_c), round(magazzini_list[int(lista_punti_neri[i])][0],6), round(magazzini_list[int(lista_punti_neri[i])][1],6), round(capex_singolo/1000,1), round(singolo_costo_sx/1000,1), round(singolo_costo_dx/1000,1), quanto_entra, quanto_esce, percentuale_uso]
            print('\t\t'.join(str(round(numero,3)) for numero in da_scrivere))
            righe_da_scrivere.append(da_scrivere)

    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)         
        csvwriter.writerow(nomi_colonne)         
        csvwriter.writerows(righe_da_scrivere)
    print(f'BREAKDOWN:\nCAPEX= {round(riassunto_CAPEX/1E6,1)} M€\tSX= {round(riassunto_SX/1E6,1)} M€\tDX= {round(riassunto_DX/1E6,1)} M€')
    totale_opex_elettrico_20=61.9  *  50  * domanda_complessiva * 20
    print(f'OPEX_20 elettrico = {round(totale_opex_elettrico_20/1E6,1)} M€')
    print(f'TOTALE: {round((riassunto_CAPEX + riassunto_SX + riassunto_DX + totale_opex_elettrico_20)/1E6,1)} M€\tSOLUZIONE: {round(instance.cost(),1)} M€')
    
    print(f'P2G necessari: {len(lista_punti_neri)}\tINSTALLAZIONI FITTIZIE: {contafasulli}')
    print(f'H2_generato: {round(sum(lista_uscite_punti_neri),1)} t/y\tDomanda aggregata: {round(domanda_complessiva,1)} t/y')
    filename = "utenti.csv"
    nomi_colonne = ['id_utente', 'consumo', 'longitudine', 'latitudine']   
    righe_da_scrivere=[]
    for i in range(len(destinations_list)):    
        righe_da_scrivere.append([i, domande_casuali[i], round(destinations_list[i][0],6), round(destinations_list[i][1],6)])
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)         
        csvwriter.writerow(nomi_colonne)         
        csvwriter.writerows(righe_da_scrivere)

    filename = "frazioni_sx.csv"
    nomi_colonne = ['id_produttore', 'id_convertitore', 'frazione']
    righe_da_scrivere=lista_xo_ridotta
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)         
        csvwriter.writerow(nomi_colonne)         
        csvwriter.writerows(righe_da_scrivere)

    filename = "frazioni_dx.csv"
    nomi_colonne = ['id_convertitore', 'id_utente', 'frazione']
    righe_da_scrivere=lista_xd_ridotta
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)         
        csvwriter.writerow(nomi_colonne)         
        csvwriter.writerows(righe_da_scrivere)


    filename = "distanze_sx.csv"
    nomi_colonne = ['id_produttore', 'id_convertitore', 'distanza']
    righe_da_scrivere=co_dist_mtrx
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)          
        csvwriter.writerows(righe_da_scrivere)

    filename = "distanze_sx_uniche.csv"
    nomi_colonne = ['id_produttore', 'id_convertitore', 'distanza']
    righe_da_scrivere=vettore_distanze_rete_P2G
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)      
        csvwriter.writerow(righe_da_scrivere)


    filename = "distanze_dx.csv"
    nomi_colonne = ['id_convertitore', 'id_utente', 'distanza']
    righe_da_scrivere=cd_dist_mtrx
    with open(cartella+prefisso+filename, 'w') as csvfile: 
        csvwriter = csv.writer(csvfile)         
        csvwriter.writerows(righe_da_scrivere)

    filename = "lista_prefissi.txt"
    with open(cartella+prefisso_iniziale+filename, "at")  as text_file:
        text_file.write(f'{prefisso}\n')        
        
    print(f'Cartella files risultati: {prefisso}')
    print(f'Scenario: {opzione_consumi} Anno: {anno_di_riferimento}')
    print(f'Truck_autonomy: {truck_autonomy} pct: {frazione_sostituita}')
    if iterazioni_sim >= iterazioni_da_avviare:
        break
print(f'prefisso territorio files risultati: {prefisso_territorio}')
    
print(f'\n\tPREFISSO INIZIALE = {prefisso_iniziale}')